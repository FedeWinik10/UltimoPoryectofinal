import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const Compra = () => {
  const { id } = useParams();
  const [producto, setProducto] = useState(null);

  useEffect(() => {
    fetchProducto(id);
  },);

  const fetchProducto = (productoId) => {
    axios
      .get(`http://localhost:3001/producto`+id)
      .then((response) => {
        console.log(response);
        setProducto(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  if (!producto) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  return (
    <div>
      <h2>Detalles de la compra</h2>
      <p>Nombre: {producto.Nombre}</p>
      <img src={producto.Imagen} alt={producto.Nombre} style={{ width: '80px' }} />
    </div>
  );
};

export default Compra;