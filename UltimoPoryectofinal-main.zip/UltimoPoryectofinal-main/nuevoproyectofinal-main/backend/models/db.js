const config = {
    user: 'usuario1',
    password: 'Producto',
    server: 'A-PHZ2-CIDI-030',
    database: 'Proyectofinal',
    options:{
        trustServerCertificate: true,
        trustedConnection: true,
    },
}
export default config;