class Pedidos{
    idpedido;
    idusuario;
    estado;
    idpromocion;    
}
export default Pedidos;