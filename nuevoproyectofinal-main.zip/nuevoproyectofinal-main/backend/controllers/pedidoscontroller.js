import { Router } from 'express';
import   { PedidosService }  from '../services/pedidoService.js';
const router = Router();
import { Pedidos } from '../models/pedido.js';

router.get('/',  async (req, res)=> {
    const ps=new PedidosService();
    const getAll = await ps.getPedidos();
    res.status(200).send(getAll)
});
router.get('/api/pedido/:id',  async (req, res)=> {
    const id = req.params.id;
    if(id < 1){
        res.status(400);
    }
    const ps=new PedidosService();
    const getById = await ps.getPedidoById(id);
    if(getById == null){
        res.status(404);
    }
    res.status(200).send(getById);
});
router.post('/api/pedido', async (req, res)=>{
    const pedido = new Pedidos();
    const ps=new PedidosService();
    pedido.estado = req.body.Estado;
    pedido.idusuario = req.body.IdUsuario;
    const cPedido = await ps.createPedido(pedido);
    res.status(201).send(cPedido);
});
router.put('/api/pedido/:id', async (req, res)=>{
    const id = req.params.id;
    if(id != req.body.Id){
        res.status(400).send();
    }
    const pedido = new Pedido();
    pedido.estado = req.body.Estado;
    pedido.idusuario = req.body.IdUsuario;
    const update = await Pedido.updatePedidoById(id, pedido);
    if(update.rowsAffected[0] == 0){
        res.status(404).send();
    }
    res.send(update); 
});
router.delete('/api/pedido/:id',  async (req, res)=>{
    const id = req.params.id;
    if(id < 1){
        res.status(400).send();
    }
    const resultDelete = await Pedido.deletePedidoById(id);
    console.log(resultDelete);
    if(resultDelete.rowsAffected[0] == 0){
        res.status(404).send()
    }
    res.status(200).send();
});

router.post('/api/pedidoitem/',  async (req, res)=> {
    const pedido = new Pedidos();
    const ps=new PedidosService();
    pedido.estado = req.body.Estado;
    pedido.idusuario = req.body.IdUsuario;
    pedido.items = req.body.items;
    const cPedido = await ps.createPedido(pedido);
    res.status(201).send(cPedido);
});



export default router;