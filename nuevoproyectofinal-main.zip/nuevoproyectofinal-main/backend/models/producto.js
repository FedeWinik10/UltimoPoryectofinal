class Productos{
    idproducto;
    precio;
    calorias;
    descripcion;
    nombre;    
}
export default Productos;