export class Producto {
    constructor(nombre, precio, imagen, descripcion) {
      this.nombre = nombre;
      this.precio = precio;
      this.imagen = imagen;
      this.descripcion = descripcion;
    }
  }