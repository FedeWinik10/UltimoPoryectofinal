class Usuario{
    idusuario;
    nombre;
    apellido;
    contraseña;    
}
export default Usuario;