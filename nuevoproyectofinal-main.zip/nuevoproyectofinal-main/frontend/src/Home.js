import React from 'react';
import { Link } from 'react-router-dom';  
import AppBoton from './AppBoton';

const Home = () => {
  const centerTextStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    textAlign: 'center',
    position: 'relative',
  };

  return (
    <div style={centerTextStyle}>
      <div
        style={{
          position: 'absolute',
          top: '10px',
          right: '10px',
          fontSize: '30px',
          zIndex: 1,
        }}
      >
        Gonzalo Plager
      </div>
      <img
        src="personaje.png"
        alt="Personaje"
        style={{
          position: 'absolute',
          top: '10px',
          right: '200px',
          width: '50px',
          height: 'auto',
          zIndex: 1,
        }}
      />
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <h2>Como Contactarnos</h2>
        <div style={{ display: 'flex', alignItems: 'center', marginLeft: '10px' }}>
          <img
            src="Instagram.png"
            alt="Instagram"
            style={{
              width: '100px',
              height: 'auto',
            }}
          />
          <img
            src="Arroba.png"
            alt="Arroba"
            style={{
              width: '100px',
              height: 'auto',
            }}
          />
          <img
            src="Whatsapp.png"
            alt="Whatsapp"
            style={{
              width: '50px',
              height: 'auto',
            }}
          />
          <img
            src="NutraCanning.png"
            alt="NutraCanning"
            style={{
              position: 'absolute',
              top: '10px',
              left: '200px',
              width: '300px',
              height: 'auto',
              zIndex: 1,
            }}
          />
          <img
            src="NumeroTelefono.png"
            alt="NumeroTelefono"
            style={{
              width: '100px',
              height: 'auto',
            }}
          />
        </div>
      </div>
      <AppBoton />
      <Link to="/compra">
        <img
          src="Compra.png"
          alt="Compra"
          style={{
            position: 'absolute',
            top: '60px',
            right: '100px',
            width: '200px',
            height: 'auto',
            zIndex: 1,
          }}
        />
      </Link>

      {}
      <Link to="/pedido">
        <button
          style={{
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            background: 'blue',
            color: 'white',
            padding: '10px 20px',
            border: 'none',
            cursor: 'pointer',
          }}
        >
          Pedidos
        </button>
      </Link>
    </div>
  );
};

export default Home;
