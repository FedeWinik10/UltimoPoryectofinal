// AppBoton.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

export default function AppBoton() {
  const [pedidos, setPedidos] = useState([]);

  useEffect(() => {
    fetchImage();
  }, []);

  const fetchImage = () => {
    axios
      .get('http://localhost:3001/pedido')
      .then((response) => {
        console.log(response);
        setPedidos(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleVerDetalles = (id) => {
    
    console.log(`Detalles del pedido con ID: ${id}`);
  };

  if (pedidos.length === 0) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  return (
    <div>
      <div className="card-container">
        {pedidos.map((pedido) => (
          <div key={pedido.id} className="card">
            <div className="card-body">
              <h5 className="card-title" style={{ fontSize: '14px' }}>{pedido.IdUsuario}</h5>
              <p className="card-text" style={{ fontSize: '14px' }}>{pedido.Estado}</p>
              <button onClick={() => handleVerDetalles(pedido.id)} className="ver-detalles-button">
                Ver Detalles
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
