import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Pedido = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (username === 'hola' && password === 'hola') {
      navigate('/home');
    } else {
      alert('Credenciales incorrectas');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100vh', justifyContent: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <h2>Como Contactarnos</h2>
        <div style={{ display: 'flex', alignItems: 'center', marginLeft: '10px' }}>
          <img
            src="Instagram.png"
            alt="Instagram"
            style={{
              width: '100px',
              height: 'auto',
            }}
          />
          <img
            src="Arroba.png"
            alt="Arroba"
            style={{
              width: '100px',
              height: 'auto',
            }}
          />
          <img
            src="Whatsapp.png"
            alt="Whatsapp"
            style={{
              width: '50px',
              height: 'auto',
            }}
          />
          <img
            src="NumeroTelefono.png"
            alt="NumeroTelefono"
            style={{
              width: '100px',
              height: 'auto',
            }}
          />
          
        </div>
      </div>
      <div>
        <h2>Iniciar Sesión</h2>
        <input
          type="text"
          placeholder="Usuario"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin}>Iniciar Sesión</button>
        <Link to="/registro">
          <button>Registrarse</button>
        </Link>
      </div>
      <div
        style={{
          position: 'absolute',
          top: '10px',
          right: '10px',
          fontSize: '30px',
        }}
      >
        Iniciar Sesión
      </div>
      <img
        src="personaje.png"
        alt="Personaje"
        style={{
          position: 'absolute',
          top: '10px',
          right: '200px',
          width: '50px',
          height: 'auto',
        }}
      />
      <img
        src="NutraCanning.png"
        alt="NutraCanning"
        style={{
          position: 'absolute',
          top: '10px',
          left: '200px',
          width: '300px',
          height: 'auto',
          zIndex: 1,
        }}
      />
    </div>
  );
};

export default Pedido;