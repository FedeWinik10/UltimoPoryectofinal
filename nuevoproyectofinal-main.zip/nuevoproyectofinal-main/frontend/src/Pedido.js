import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

export default function AppBoton() {
  const [pedidos, setPedidos] = useState([]);

  useEffect(() => {
    fetchImage();
  }, []);

  const fetchImage = () => {
    axios
      .get('http://localhost:3001/pedido')
      .then((response) => {
        console.log(response);
        setPedidos(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  if (pedidos.length === 0) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  return (
    <div>
      <div className="card-container">
        {pedidos.map((pedido) => (
          <div key={pedido.id} className="card">
            <img src={pedido.Imagen} className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title" style={{ fontSize: '14px' }}>{pedido.IdUsuario}</h5>
              <p className="card-text" style={{ fontSize: '14px' }}>${pedido.Estado}</p>
              
            </div>
          </div>
        ))}
      </div>

      
    </div>
  );
}