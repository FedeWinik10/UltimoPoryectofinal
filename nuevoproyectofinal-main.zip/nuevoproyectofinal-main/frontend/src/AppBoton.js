import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './App.css';

export default function AppBoton() {
  const [productos, setProductos] = useState([]);
  const [productoSeleccionado, setProductoSeleccionado] = useState(null);
  const [imagenProducto, setImagenProducto] = useState('');

  useEffect(() => {
    fetchImage();
  }, []);

  const fetchImage = () => {
    axios
      .get('http://localhost:3001/producto')
      .then((response) => {
        console.log(response);
        setProductos(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleComprar = (nombre, imagen) => {
    setProductoSeleccionado(nombre);
    setImagenProducto(imagen);
  };

  if (productos.length === 0) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  return (
    <div>
      <div className="card-container">
        {productos.map((producto) => (
          <div key={producto.id} className="card">
            <img src={producto.Imagen} className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title" style={{ fontSize: '14px' }}>{producto.Nombre}</h5>
              <p className="card-text" style={{ fontSize: '14px' }}>${producto.Precio}</p>
              
              <Link to={`/detalleproductos/${producto.IdProducto}`}>
                <button>Detalle</button>
              </Link>
              <button onClick={() => handleComprar(producto.Nombre, producto.Imagen)}>Agregar</button>
            </div>
          </div>
        ))}
      </div>

      {productoSeleccionado && (
        <div>
          <h2 style={{ fontSize: '20px' }}>Detalles de la compra</h2>
          <p style={{ fontSize: '18px' }}>Nombre: {productoSeleccionado}</p>
          {imagenProducto && (
            <img src={imagenProducto} alt={productoSeleccionado} style={{ width: '80px' }} />
          )}
        </div>
      )}
    </div>
  );
}
