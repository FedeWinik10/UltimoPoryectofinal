import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const EliminarProducto = () => {
  const { id } = useParams();
  const [producto, setProductos] = useState(null);

  useEffect(() => {
    fetchImage();
  });

  const fetchImage = () => {
    axios
      .delete('http://localhost:3001/producto/api/producto/'+ id)
      .then((response) => {
        setProductos(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  if (!producto) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  
};

export default EliminarProducto;
