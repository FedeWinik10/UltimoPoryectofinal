import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
import axios from 'axios';

const DetalleProductos = () => {
  const { id } = useParams();
  const [producto, setProductos] = useState(null);

  useEffect(() => {
    fetchImage();
  });

  const fetchImage = () => {
    axios
      .get('http://localhost:3001/producto/api/producto/'+ id)
      .then((response) => {
        setProductos(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  if (!producto) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh'
    }}>
      <p>Nombre: {producto[0].Nombre}</p>
      <p>Precio: {producto[0].Precio}</p>
      <p>Descripción: {producto[0].Descripcion}</p>
      <img src={producto[0].Imagen} alt={producto.Nombre} style={{ width: '200px' }} />
      <Link to="/home"> {}
        <button style={{ marginTop: '20px' }}>Agregar a la compra</button>
      </Link>
      <Link to="/home"> {}
        <button style={{ marginTop: '20px' }}>Eliminar</button>
      </Link>
    </div>
  );
};

export default DetalleProductos;
