import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Login';
import Home from './Home';
import Registro from './Registrarse';
import DetalleProductos from './DetalleProductos';
import Compra from './Compra';
import Pedido from './Pedido';
import EliminarProducto from './EliminarProducto';

function App() {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/home" element={<Home />} />
          <Route path="/registrarse" element={<Registro />} />
          <Route path="/detalleproductos/:id" element={<DetalleProductos />} />
          <Route path="/eliminarproducto/:id" element={<EliminarProducto />} />
          <Route path="/compra" element={<Compra />} />
          <Route path="/pedido" element={<Pedido />} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;

