
export class Pedidos {
    constructor(estado, idusuario, items) {
      this.estado = estado;
      this.idusuario = idusuario;
      this.items = items;
    }
  }