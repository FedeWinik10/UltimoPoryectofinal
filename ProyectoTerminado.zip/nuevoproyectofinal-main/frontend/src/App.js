import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Login';
import Home from './Home';
import Registro from './Registrarse';
import DetalleProductos from './DetalleProductos';
import Compra from './Compra';
import Pedido from './Pedido';
import EliminarProducto from './EliminarProducto';

function App() {
  const [carrito, setCarrito] = useState([]);

  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/home" element={<Home />} />
          <Route path="/registrarse" element={<Registro />} />
          <Route path="/detalleproductos/:id" element={<DetalleProductos carrito={carrito} setCarrito={setCarrito}/>} />
          <Route path="/eliminarproducto/:id" element={<EliminarProducto />} />
          <Route path="/compra" element={<Compra carrito={carrito}/>} />
          <Route path="/pedido" element={<Pedido />} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;

