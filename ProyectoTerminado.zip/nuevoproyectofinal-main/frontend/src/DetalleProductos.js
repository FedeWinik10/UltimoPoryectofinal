import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const DetalleProductos = ({carrito, setCarrito}) => {
  const { id } = useParams();
  const [producto, setProductos] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchImage();
  });

  function eliminarproducto() {
    axios
      .delete('http://localhost:3001/producto/api/producto/'+ id)
      .then(() => {
        console.log('Producto eliminado');
      })
      .catch((error) => {
        console.log(error);
      });
  }

  const agregarACarrito = (prod) => {
    setCarrito([...carrito, prod]);
    navigate("/home");
  }

  const fetchImage = () => {
    axios
      .get('http://localhost:3001/producto/api/producto/'+ id)
      .then((response) => {
        setProductos(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  if (!producto) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh'
    }}>
      <p>Nombre: {producto[0].Nombre}</p>
      <p>Precio: {producto[0].Precio}</p>
      <p>Descripción: {producto[0].Descripcion}</p>
      <img src={producto[0].Imagen} alt={producto.Nombre} style={{ width: '200px' }} />
      <button onClick={() => agregarACarrito(producto[0])} style={{ marginTop: '20px' }}>Agregar a la compra</button>
      <button onClick={eliminarproducto} style={{ marginTop: '20px' }}>Eliminar</button>
    </div>
  );
};

export default DetalleProductos;
