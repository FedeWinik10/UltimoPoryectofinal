import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Compra = ({ carrito }) => {
  const { id } = useParams();
  const [producto, setProducto] = useState(null);

  const agregarAPedido = () => {
    axios
      .post('http://localhost:3001/pedido/api/pedidoitem', {
        "IdUsuario": 2,
        "Estado": "Pendiente",
        "items": carrito.map(c => {
          return {
            IdProducto: c.IdProducto,
            Cantidad: 1,
            Total: c.Precio,
          }
        })
      })
      .then((response) => {
        console.log(response);
        setProducto(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
    //navigate("/home");
  }

  if (!producto) {
    return (
      <div className="Fondo">
        {carrito.map((c, index) => (
          <div key={index}>
            <h1>{c.Nombre}</h1>
            <h2>{c.Descripcion}</h2>
            <h2>{c.Precio}</h2>
            <img src={c.Imagen} alt={c.Nombre} />
          </div>
        ))}
        <button onClick={() => agregarAPedido(producto)} style={{ marginTop: '20px' }}>Pedir</button>
      </div>
    );
  }

};

export default Compra;
