import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const DetalleProductos = () => {
  const { id } = useParams();
  const [pedidoitem, setProductos] = useState(null);

  useEffect(() => {
    fetchImage();
  });

  

  const fetchImage = () => {
    axios
      .get('http://localhost:3001/pedido/api/pedido/'+ id)
      .then((response) => {
        setProductos(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  if (!pedidoitem) {
    return (
      <div className="Fondo">
        <h1>Cargando...</h1>
      </div>
    );
  }

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh'
    }}>
      <p>Nombre: {pedidoitem[0].Cantidad}</p>
      <p>Precio: {pedidoitem[0].Total}</p>
      <Link to="/pedido">
        <button style={{ marginTop: '20px' }}>Volver</button>
      </Link>
    </div>
  );
};

export default DetalleProductos;