import React, { useState } from 'react';

const Registro = () => {
  const [usuario, setUsuario] = useState({
    nombre: '',
    apellido: '',
    contraseña: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUsuario({
      ...usuario,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await 
      console.log('Usuario creado:', response);
      
    } catch (error) {
      console.error('Error al crear el usuario:', error);
      
    }
  };

  return (
    <div>
      <h2>Registro de Usuario</h2>
      <form onSubmit={handleSubmit}>
        <label>Nombre:</label>
        <input
          type="text"
          name="nombre"
          value={usuario.nombre}
          onChange={handleChange}
        />
        <br />
        <label>Apellido:</label>
        <input
          type="text"
          name="apellido"
          value={usuario.apellido}
          onChange={handleChange}
        />
        <br />
        <label>Contraseña:</label>
        <input
          type="password"
          name="contraseña"
          value={usuario.contraseña}
          onChange={handleChange}
        />
        <br />
        <button type="submit">Registrarse</button>
      </form>
    </div>
  );
};

export default Registro;
